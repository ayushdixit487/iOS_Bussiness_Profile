//
//  ClcnVC.swift
//  Bussiness_Profile
//
//  Created by Hence4th on 30/01/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit

class ClcnVC: UICollectionViewCell {
    
    @IBOutlet weak var imgvw: UIImageView!
    @IBOutlet weak var btncell2: UIButton!
}
