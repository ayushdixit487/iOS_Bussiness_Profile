//
//  ViewController.swift
//  Bussiness_Profile
//
//  Created by Hence4th on 29/01/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var btnsbmt: UIButton!

    @IBOutlet weak var clctnvw2: UICollectionView!
//    @IBOutlet weak var clcnvc2: ClcnVC!
   // @IBOutlet weak var clcnVC: ClctnVCCollectionViewCell!
    var bjadk : [UIImage] = []
    var arr : [UIImage] = []
     var select1 = false
    var imagePicker = UIImagePickerController()
    
    @IBOutlet weak var clctnvw1: UICollectionView!
    @IBOutlet weak var lblcbp: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        lblcbp.font = UIFont.boldSystemFont(ofSize: 20)
        lblcbp.textAlignment = .center
        btnsbmt.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        btnsbmt.layer.cornerRadius = 5
    }

   

}

extension ViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UINavigationControllerDelegate, UIImagePickerControllerDelegate{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == clctnvw1{
        return 1 + bjadk.count
        }else{
         return 1 + arr.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        print("Select")
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == clctnvw1{
        if indexPath.row == 0{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ClctnVCCollectionViewCell", for: indexPath)as! ClctnVCCollectionViewCell
             cell.btncell1.addTarget(self, action: #selector(btnActSelect(_:)), for: .touchUpInside)
            return cell
        }else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "clcnVC", for: indexPath) as! ClcnVC
            cell.imgvw.image = bjadk[indexPath.row-1]
            cell.btncell2.tag = indexPath.row - 1
            
            cell.btncell2.addTarget(self, action:  #selector(btnActDelete(_:)), for: .touchUpInside)
            
            return cell
        }
        }
        else{
            if indexPath.row == 0{
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ClctnVC3", for: indexPath)as! ClctnVC3
                cell.btnadd.addTarget(self, action: #selector(btnActSelect1(_:)), for: .touchUpInside)
                return cell
            }else{
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ClctnVC4", for: indexPath) as! ClctnVC4
                cell.imgvw2.image = arr[indexPath.row-1]
                cell.btncncl.tag = indexPath.row - 1
                
                cell.btncncl.addTarget(self, action:  #selector(btnActDelete1(_:)), for: .touchUpInside)
                
                return cell
            }

        }
        
        
    }
   
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        
        print("Button")
    }
    
 
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            if select1{
            bjadk.append(pickedImage)
            
                clctnvw1.reloadData()
            }else{
                arr.append(pickedImage)
                clctnvw2.reloadData()
            }
            
        }
        dismiss(animated: true, completion: nil)
    }
    func btnActSelect(_ sender: UIButton){
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
            print("Button capture")
            
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary
            imagePicker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!

            imagePicker.allowsEditing = false
            select1 = true
            
            self.present(imagePicker, animated: true, completion: nil)
        }
        
    }
    func btnActSelect1(_ sender: UIButton){
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
            print("Button capture")
            
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary
            imagePicker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
            
            imagePicker.allowsEditing = false
            select1 = false
            
            self.present(imagePicker, animated: true, completion: nil)
        }
        
    }
    
    func btnActDelete(_ sender: UIButton){
           bjadk.remove(at: sender.tag)
            clctnvw1.reloadData()
            }
    
    func btnActDelete1(_ sender: UIButton){
        
        arr.remove(at: sender.tag)
        clctnvw2.reloadData()
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }

            
}         
            

