//
//  ClctnVC3.swift
//  Bussiness_Profile
//
//  Created by Hence4th on 30/01/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit

class ClctnVC3: UICollectionViewCell {
    
    @IBOutlet weak var btnadd: UIButton!
    var select : Bool = false
}
