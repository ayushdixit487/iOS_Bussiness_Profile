//
//  ClctnVC4.swift
//  Bussiness_Profile
//
//  Created by Hence4th on 30/01/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit

class ClctnVC4: UICollectionViewCell {
    @IBOutlet weak var imgvw2: UIImageView!
    
    @IBOutlet weak var btncncl: UIButton!
}
