//
//  ClctnVCCollectionViewCell.swift
//  Bussiness_Profile
//
//  Created by Hence4th on 30/01/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit

class ClctnVCCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var btncell1: UIButton!
    var select : Bool = false 
    
}
